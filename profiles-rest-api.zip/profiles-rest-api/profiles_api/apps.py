from django.apps import AppConfig


class ProfilesApiConfig(AppConfig):
    name = 'profiles_api'
